Login - aron@gmail.com
Pw - aron

0. run `npm install` in both frontend and backend folder
1. run command `npm run start`in backend folder and run `npm run start` or `npm start  "set PORT=3000 && react-scripts"` in frontend folder
2. I have create frontend in REACT JS and Backend in NODE JS
3. In this only admin can visit http://localhost:3000/manage-users
4. normal user has no functionality, can only login

API's
5. to make admin ac hit SIGNUP API on postman - Method - POST - http://localhost:1900/user/signup -
    JSON data 
    {
        "name": "aron",
        "email": "aron@gmail.com",
        "password":"aron",
        "cpassword": "aron",
        "makeadmin": "1",
        "city": "ludhiana",
        "state": "punjab",
        "country": "India"
    }
6. DELETE API - Method - Delete - http://localhost:1900/user/delete-user/63138bb74f90d7e8a1b16260
7. LOGIN API - Method - POST - http://localhost:1900/user/login 
    JSON DATA
    {
        "email": "mukesh@gmail.com",
        "password":"mukesh"
    }
    
