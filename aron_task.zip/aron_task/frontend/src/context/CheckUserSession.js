import { createContext, useEffect, useState } from "react";
import { Navigate, useNavigate } from "react-router-dom";
const UserSessionContext = createContext()


const UserSession = (props) => {
    const navigate = useNavigate()
    
    const [loggedInUser,setLoggedInUser] = useState(localStorage.getItem('loggedInUser') ? JSON.parse(localStorage.getItem('loggedInUser')) : null)
    useEffect(()=>{
        // console.log("authtoken user session",localStorage.getItem('loggedInUser'))
        let loggedInUser = localStorage.getItem('loggedInUser') ? JSON.parse(localStorage.getItem('loggedInUser')): null
        if(localStorage.getItem('loggedInUser')){
            loggedInUser = JSON.parse(localStorage.getItem('loggedInUser'))
            setLoggedInUser(loggedInUser)
        }else{
            localStorage.clear();
            navigate("/")
        }
    },[])
    return (
        <UserSessionContext.Provider value={{loggedInUser,setLoggedInUser}}>
            {props.children}
        </UserSessionContext.Provider>
    )
}
export default UserSession
export {UserSessionContext}
