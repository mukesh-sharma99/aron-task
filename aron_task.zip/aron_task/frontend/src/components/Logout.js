import React, {useContext} from "react";
import { Navigate, useNavigate } from "react-router-dom";
import { UserSessionContext } from "../context/CheckUserSession";
const Logout = () => {
    const userSessionContext = useContext(UserSessionContext)
    const {setLoggedInUser} = userSessionContext
    setLoggedInUser(null)
    localStorage.clear()
    // const navigate = useNavigate()
    // navigate("/")
    // return
    return <Navigate to="/" replace />
}

export default Logout