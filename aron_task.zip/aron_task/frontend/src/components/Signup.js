import React, { useContext, useEffect, useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import {UserSessionContext} from "../context/CheckUserSession"
import env from "../env"

const Signup = () => {
    const userSessionContext = useContext(UserSessionContext)
    const {setLoggedInUser,loggedInUser} = userSessionContext
    const navigate = useNavigate()
    const [credentials,setCredentials] = useState({name:"",email: "", city:"", state:"", country:"", password: ""})
    const [submitBtnDisable,setSubmitBtnDisable] = useState(false)
    // console.log(process.env.REACT_APP_BACKEND_HOST_URL)
    const handleSubmit = async(e) =>{
        e.preventDefault()
        // console.log(credentials)
        setSubmitBtnDisable(true)
        let response = await fetch(`${env.SERVER_URI}${env.SERVER_PORT}/user/signup/` ,{
            method: "POST",
            headers: {
                "Content-Type" : "application/json",
            },
            body: JSON.stringify(credentials)
        })
        let json = await response.json()
        setSubmitBtnDisable(false)
        alert(json.response.message)
        if(json.response.success){
            navigate("/") 
            return 
        }
    }
    const onChangeFields = (e)=>{
        // console.log(credentials)
        setCredentials({...credentials,[e.target.name]: e.target.value})
    }
    useEffect(()=>{
        if(localStorage.getItem('loggedInUser')){
            navigate('/')
        }
    },[])
    return (
        <>  
            <div className="row justify-content-center">
                <div className='col-md-6'>
                    <div className='container-fluid'>
                        <form onSubmit={handleSubmit}>
                        <i><h6>This form has only basic validations !</h6></i>
                        <div className="g-signin2" data-onsuccess="onSignIn"></div>
                            <div className="form-group">
                                <label htmlFor="name"> Name</label>
                                <input type="text" className="form-control" id="name" aria-describedby="nameHelp" placeholder="Enter name" name='name' onChange={onChangeFields} required />
                            </div>
                            <div className="form-group">
                                <label htmlFor="email">Email</label>
                                <input type="email" className="form-control" id="email" aria-describedby="emailHelp" placeholder="Enter email" name='email' onChange={onChangeFields} required />
                                <small id="emailHelp" className="form-text text-muted">We'll never share your email with anyone else.</small>
                            </div>
                            <div className="form-group">
                                <label htmlFor="city">City</label>
                                <input type="text" className="form-control" id="city" placeholder="City" name="city" onChange={onChangeFields} required />
                            </div>
                            <div className="form-group">
                                <label htmlFor="state">State</label>
                                <input type="text" className="form-control" id="State" placeholder="State" name="state" onChange={onChangeFields} required />
                            </div>
                            <div className="form-group">
                                <label htmlFor="country">Country</label>
                                <input type="text" className="form-control" id="country" placeholder="Country" name="country" onChange={onChangeFields} required />
                            </div>
                            <div className="form-group">
                                <label htmlFor="password">Password</label>
                                <input type="password" className="form-control" id="password" placeholder="Password" name="password" onChange={onChangeFields} required />
                            </div>
                            <div className="form-group">
                                <label htmlFor="cpassword">Confirm Password</label>
                                <input type="password" className="form-control" id="cpassword" placeholder="Confirm Password" name="cpassword" onChange={onChangeFields} required />
                            </div>
                            <button type="submit" className="btn btn-primary my-3 mx-2" disabled={submitBtnDisable} >Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Signup