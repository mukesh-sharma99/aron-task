import React from "react";

const Home = () => {
    return (
        <>
            <h1>This Is Home Component</h1>
            <h5>Login to admin account to see dashboard</h5>
            <h5>Normal User has no Facility</h5>
        </>
    )
}

export default Home