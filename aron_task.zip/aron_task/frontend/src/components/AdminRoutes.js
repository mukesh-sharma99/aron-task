import React, { useContext } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import { UserSessionContext } from "../context/CheckUserSession";


const AdminRoutes = ({children}) => {
    const navigate = useNavigate()
    const userSessionContext = useContext(UserSessionContext)
    const {loggedInUser} = userSessionContext
    if(loggedInUser && loggedInUser.authToken && Object.keys(loggedInUser).length > 0 && loggedInUser.usertype === "admin"){
        return children
    }
    navigate('/')
    return
    
}

export default AdminRoutes