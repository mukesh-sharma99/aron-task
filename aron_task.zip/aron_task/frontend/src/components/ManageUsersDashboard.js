
import React, { useState, useContext, useEffect } from "react";
import { useParams } from "react-router-dom";
import DataTable from "react-data-table-component";
import DataTableExtensions from "react-data-table-component-extensions"
import "react-data-table-component-extensions/dist/index.css"
import axios from "axios";
import { UserSessionContext } from "../context/CheckUserSession";
import env from "../env"
import Modal from "react-bootstrap/Modal"
import Button from "react-bootstrap/Button";

const ManageUsersDashboard = () => {
    const userSessionContext = useContext(UserSessionContext)
    const { loggedInUser } = userSessionContext
    const params = useParams()
    const [data, setGridData] = useState([])
    const [submitBtnDisable, setSubmitBtnDisable] = useState(false)
    const [showAddUserModal, setShowAddUserModal] = useState(false)
    const [credentials, setCredentials] = useState({ _id: null, name: "", email: "", city: "", state: "", country: "", password: "", cpassword: "" })
    const [cityDDArr, setCityDDArr] = useState([])
    const [stateDDArr, setStateDDArr] = useState([])
    const [countryDDArr, setCountryDDArr] = useState([])
    const [cityFilterValue, setCityFilterValue] = useState("")
    const [stateFilterValue, setStateFilterValue] = useState("")
    const [countryFilterValue, setCountryFilterValue] = useState("")
    const [customFilterValues, setCustomFilterValues] = useState({ cityFilterValue: "", stateFilterValue: "", countryFilterValue: "" })

    const cursorPointer = {
        cursor: "pointer",
    }
    const clickOnEdit = (d) => {
        setCredentials({ _id: d._id, name: d.name, email: d.email, city: d.city, state: d.state, country: d.country, password: "", cpassword: "" })
        setShowAddUserModal(true)
    }

    const columns = [
        {
            name: "User Type",
            selector: row => row.usertype,
            sortable: true
        },
        {
            name: "Name",
            selector: row => row.name,
            sortable: true
        },
        {
            name: "Email",
            selector: row => row.email,
            sortable: true
        },
        {
            name: "City",
            selector: row => row.city,
            sortable: true
        },
        {
            name: "State",
            selector: row => row.state,
            sortable: true
        },
        {
            name: "Country",
            selector: row => row.country,
            sortable: true
        },
        {
            name: "Created At",
            selector: row => row.created_at,
            sortable: true
        },
        {
            name: "Updated At",
            selector: row => row.updated_at,
            sortable: true
        },
        {
            name: "Actions",
            selector: false,
            cell: (d) => [
                <span onClick={() => { clickOnEdit(d) }}>
                    <i className="fa-solid fa-pen mx-2" style={{ ...cursorPointer, ["color"]: "blue" }}></i>
                </span>, d.usertype != 'admin' &&
                <span onClick={() => { clickOnDelete(d._id) }}>
                    <i className="fa-solid fa-trash mx-2" style={{ ...cursorPointer, ["color"]: "red" }}></i>
                </span>
            ]
        }
    ]
    let tableData = { columns, data }
    const loadGrid = async () => {
        const response = await axios({
            url: `${env.SERVER_URI}${env.SERVER_PORT}/user/get-all-users/`,
            method: "POST",
            headers: {
                "ContentType": "application/json",
                "authToken": loggedInUser.authToken,
            },
            data: { cityFilterValue: customFilterValues.cityFilterValue, stateFilterValue: customFilterValues.stateFilterValue, countryFilterValue: customFilterValues.countryFilterValue }
        })
        if (response.data.response.success && response.status === 200) {
            setGridData(response.data.response.data.users)
            tableData = { columns, data }
        }
       
        setCityDDArr(response.data.response.data.cities)
        setStateDDArr(response.data.response.data.states)
        setCountryDDArr(response.data.response.data.countries)
      
    }
    let resetAllCustomFilters = () => {
        // setCountryFilterValue('')
        // setCityFilterValue('')
        // setStateFilterValue('')
        setCustomFilterValues({ cityFilterValue: "", stateFilterValue: "", countryFilterValue: "" })
    }
    const onChangeCityFilter = (e) => {
        console.log(e.target.value)
        setCustomFilterValues({ ...customFilterValues, cityFilterValue: e.target.value })
    }
    const onChangeStateFilter = (e) => {
        console.log(e.target.value)
        setCustomFilterValues({ ...customFilterValues, stateFilterValue: e.target.value })
    }
    const onChangeCountryFilter = (e) => {
        console.log(e.target.value)
        setCustomFilterValues({ ...customFilterValues, countryFilterValue: e.target.value })
    }
    const onChangeFields = (e) => {
        // console.log(credentials)
        setCredentials({ ...credentials, [e.target.name]: e.target.value })
    }
    const handleSubmit = async (e) => {
        e.preventDefault()
        setSubmitBtnDisable(true)
        // console.log(credentials)
        if (credentials.name.trim().length <= 0) {
            alert("Name should be filled!")
            setSubmitBtnDisable(false)
            return
        } else if (credentials.email.trim().length <= 0) {
            alert("Email should be filled!")
            setSubmitBtnDisable(false)
            return
        } else if (credentials.city.trim().length <= 0) {
            alert("City should be filled!")
            setSubmitBtnDisable(false)
            return
        } else if (credentials.state.trim().length <= 0) {
            alert("State should be filled!")
            setSubmitBtnDisable(false)
            return
        } else if (credentials.country.trim().length <= 0) {
            alert("Country should be filled!")
            setSubmitBtnDisable(false)
            return
        } else if (credentials.password.trim().length <= 0 && !credentials._id) {
            alert("Password should be filled!")
            setSubmitBtnDisable(false)
            return
        } else if (credentials.cpassword.trim().length <= 0 && !credentials._id) {
            alert("Confirm Password should be filled!")
            setSubmitBtnDisable(false)
            return
        }
        let response = await fetch(`${env.SERVER_URI}${env.SERVER_PORT}/user/signup/`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(credentials)
        })
        let json = await response.json()
        alert(json.response.message)
        setSubmitBtnDisable(false)
        if (json.response.success) {
            let resData = json.response.data
            console.log(json)
            if (credentials._id) {
                setGridData(data.map((user) => {
                    if (user._id == credentials._id) {
                        return resData
                    }
                    return user
                }))
            } else {
                let newData = [...data]
                newData.push(resData)
                setGridData(newData)
            }
            setTimeout(() => {
                setShowAddUserModal(false)
                loadGrid()
            }, 300)
            return
        }
    }
    const clickOnDelete = async (id) => {
        if (window.confirm("Do you really want to delete this user")) {
            const resp = await axios({
                url: `${env.SERVER_URI}${env.SERVER_PORT}/user/delete-user/${id}`,
                method: "delete",
                headers: {
                    "Content-Type": "application/json",
                    "authToken": loggedInUser.authToken
                }
            })
            if (resp.status === 200 && resp.data.response.success) {
                setGridData(data.filter((data) => {
                    return data._id !== id
                }))
            }
        }
    }
    useEffect(() => {
        loadGrid()
    }, [])
    useEffect(() => {
        if (!showAddUserModal) {
            setSubmitBtnDisable(false)
            setCredentials({ _id: null, name: "", email: "", city: "", state: "", country: "", password: "", cpassword: "" })
        }
    }, [showAddUserModal])
    useEffect(() => {
        loadGrid()
    }, [customFilterValues])
    return (
        <>
            <div className="MainDiv">
                <div className="jumbotron text-center bg-sky">
                    <h3>Manage Users</h3>
                </div>
                <div className="d-flex align-items-center mt-5 justify-content-between">
                    <Button onClick={() => { setShowAddUserModal(true) }}    >Add new user</Button>
                    <div className="d-flex">
                        <label className="d-flex align-items-center text-nowrap mx-4 ">By City
                            <select className="form-select mx-2" style={{ textTransform: "capitalize" }} aria-label="Default select example" onChange={onChangeCityFilter} defaultValue=''>
                                <option value="">Select Any</option>
                                {
                                    Object.keys(cityDDArr).map(function (key) {
                                        return <option key={key} value={cityDDArr[key]} selected={cityDDArr[key] == customFilterValues.cityFilterValue ? true : false}>{cityDDArr[key]}</option>
                                    })
                                }
                            </select>
                            <span className=""  onClick={() => { setCustomFilterValues({ ...customFilterValues, cityFilterValue: "" }) }}><i className="fa fa-solid fa-times" styp={cursorPointer}></i></span>
                        </label>
                        <label className="d-flex align-items-center text-nowrap mx-4 ">By State
                            <select className="form-select mx-2" style={{ textTransform: "capitalize" }} aria-label="Default select example" onChange={onChangeStateFilter} defaultValue=''>
                                <option value="">Select Any</option>
                                {
                                    Object.keys(stateDDArr).map(function (key) {
                                        return <option key={key} value={stateDDArr[key]} selected={stateDDArr[key] == customFilterValues.stateFilterValue ? true : false}>{stateDDArr[key]}</option>
                                    })
                                }
                            </select>
                            <span className=""  onClick={() => { setCustomFilterValues({ ...customFilterValues, stateFilterValue: "" }) }}><i className="fa fa-solid fa-times" styp={cursorPointer}></i></span>
                        </label>
                        <label className="d-flex align-items-center text-nowrap mx-4 ">By Country
                            <select className="form-select mx-2" style={{ textTransform: "capitalize" }} aria-label="Default select example" onChange={onChangeCountryFilter} defaultValue=''>
                                <option value="">Select Any</option>
                                {
                                    Object.keys(countryDDArr).map(function (key) {
                                        return <option key={key} value={countryDDArr[key]} selected={countryDDArr[key] == customFilterValues.countryFilterValue ? true : false}>{countryDDArr[key]}</option>
                                    })
                                }
                            </select>
                            <span className="" onClick={() => { setCustomFilterValues({ ...customFilterValues, countryFilterValue: "" }) }}><i className="fa fa-solid fa-times" styp={cursorPointer}></i></span>
                        </label>
                    </div>
                    <Button onClick={resetAllCustomFilters}    >Reset all</Button>
                </div>
                <div className="container">
                    <DataTableExtensions {...tableData}>
                        <DataTable
                            columns={columns}
                            data={data}
                            defaultSortField="Name"
                            noHeader
                            defaultSortDesc={false}
                            pagination
                            highlightOnHover
                        />
                    </DataTableExtensions>
                </div>
            </div>
            <Modal show={showAddUserModal} onHide={() => { setShowAddUserModal(false) }}>
                <Modal.Header closeButton>
                    Add/Edit User
                </Modal.Header>
                <Modal.Body>
                    <div className='container-fluid'>
                        <i><h6>This form has only basic validations !</h6></i>
                        <form onSubmit={handleSubmit}>
                            <div className="g-signin2" data-onsuccess="onSignIn"></div>
                            <div className="form-group">
                                <label htmlFor="name"> Name</label>
                                <input type="text" className="form-control" id="name" aria-describedby="nameHelp" placeholder="Enter name" name='name' value={credentials.name} onChange={onChangeFields} required />
                            </div>
                            <div className="form-group">
                                <label htmlFor="email">Email</label>
                                <input type="email" className="form-control" id="email" aria-describedby="emailHelp" placeholder="Enter email" name='email' onChange={onChangeFields} value={credentials.email} required />
                                <small id="emailHelp" className="form-text text-muted">We'll never share your email with anyone else.</small>
                            </div>
                            <div className="form-group">
                                <label htmlFor="city">City</label>
                                <input type="text" className="form-control" id="city" placeholder="City" name="city" onChange={onChangeFields} value={credentials.city} required />
                            </div>
                            <div className="form-group">
                                <label htmlFor="state">State</label>
                                <input type="text" className="form-control" id="State" placeholder="State" name="state" onChange={onChangeFields} value={credentials.state} required />
                            </div>
                            <div className="form-group">
                                <label htmlFor="country">Country</label>
                                <input type="text" className="form-control" id="country" placeholder="Country" name="country" onChange={onChangeFields} value={credentials.country} required />
                            </div>
                            {
                                !credentials._id && <><div className="form-group">
                                    <label htmlFor="password">Password</label>
                                    <input type="password" className="form-control" id="password" placeholder="Password" name="password" onChange={onChangeFields} value={credentials.password} required />
                                </div>
                                    <div className="form-group">
                                        <label htmlFor="cpassword">Confirm Password</label>
                                        <input type="password" className="form-control" id="cpassword" placeholder="Confirm Password" name="cpassword" onChange={onChangeFields} value={credentials.cpassword} required />
                                    </div>
                                </>
                            }

                            <button type="submit" className="btn btn-primary my-3 mx-2" onClick={handleSubmit} disabled={submitBtnDisable} >Submit</button>
                        </form>
                    </div>
                </Modal.Body>
            </Modal>
        </>
    )
}

export default ManageUsersDashboard