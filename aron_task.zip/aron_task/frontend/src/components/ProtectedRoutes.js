import React, { useContext } from "react";
import { Navigate } from "react-router-dom";
import { UserSessionContext } from "../context/CheckUserSession";

const ProtectedRoutes = ({ children }) => {
    const userSessionContext = useContext(UserSessionContext)
    let {loggedInUser} = userSessionContext
    if(!loggedInUser){
        localStorage.clear()
        return <Navigate to="/login" replace />
    }
    return children
}
export default ProtectedRoutes