import React, {useContext} from "react"
import { Link, useLocation } from "react-router-dom"
import { UserSessionContext } from "../context/CheckUserSession"
const Navbar = () => {
  let location = useLocation()
  let userSessionContext = useContext(UserSessionContext)
  let {loggedInUser } = userSessionContext
  // console.log(loggedInUser,"nav")
  return (
    <div className='row'>
      <div className='col-md-12'>
        <nav className="col-md-12 navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
          <div className="container-fluid mx-3">
            <Link className={`navbar-brand ${location.pathname === "/" ? "active" : ''}`} to="/home">Home</Link>
            { 
              loggedInUser !== null ? 
              <>
                {/* <Link className={`navbar-brand ${location.pathname === "/fetch-my-stats" ? "active" : ''}`} to="/fetch-my-stats">My Stats</Link> */}
                {loggedInUser.usertype === "admin" && <Link className={`navbar-brand ${location.pathname === "/manage-users" ? "active" : ''}`} to="/manage-users">Dashboard</Link>}
                <Link to="/logout" className="btn btn-warning mx-2">Logout</Link>
              </>
              :
              <div>
                <Link to="/login" className="btn btn-light mx-2">Login</Link>
                <Link to="/signup" className="btn btn-success mx-2">Signup</Link>
              </div>
            }
          </div>
        </nav>
      </div>
    </div>
  )
}

export default Navbar
