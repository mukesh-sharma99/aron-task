import React, { useContext, useEffect, useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import {UserSessionContext} from "../context/CheckUserSession"

const Login = () => {
    const userSessionContext = useContext(UserSessionContext)
    const {setLoggedInUser,loggedInUser} = userSessionContext
    const navigate = useNavigate()
    const [credentials,setCredentials] = useState({email: "", password: ""})
    const [submitBtnDisable,setSubmitBtnDisable] = useState(false)
    // console.log(process.env.REACT_APP_BACKEND_HOST_URL)
    const handleSubmit = async(e) =>{
        e.preventDefault()
        setSubmitBtnDisable(true)
        let response = await fetch(`http://localhost:1900/user/login/` ,{
            method: "POST",
            headers: {
                "Content-Type" : "application/json",
            },
            body: JSON.stringify(credentials)
        })
        let json = await response.json()
        setSubmitBtnDisable(false)
        alert(json.response.message)
        if(json.response.success){
            setLoggedInUser(json.response.data.user)
            localStorage.setItem('loggedInUser',JSON.stringify(json.response.data.user))
            navigate("/") 
            return 
        }
    }
    const onChangeFields = (e)=>{
        // console.log(credentials)
        setCredentials({...credentials,[e.target.name]: e.target.value})
    }
    useEffect(()=>{
        if(localStorage.getItem('loggedInUser')){
            // <Navigate to='/' />
            navigate('/')
        }
    },[])
    return (
        <>  
            <div className="row justify-content-center">
                <div className='col-md-6'>
                    <div className='container-fluid'>
                        <form onSubmit={handleSubmit}>
                        <i><h6>This form has only basic validations !</h6></i>
                        <div className="g-signin2" data-onsuccess="onSignIn"></div>
                            <div className="form-group">
                                <label htmlFor="email">Email address</label>
                                <input type="email" className="form-control" id="email" aria-describedby="emailHelp" placeholder="Enter email" name='email' onChange={onChangeFields} required />
                                <small id="emailHelp" className="form-text text-muted">We'll never share your email with anyone else.</small>
                            </div>
                            <div className="form-group">
                                <label htmlFor="password">Password</label>
                                <input type="password" className="form-control" id="password" placeholder="Password" name="password" onChange={onChangeFields} required />
                            </div>
                            <button type="submit" className="btn btn-primary my-3 mx-2"  disabled={submitBtnDisable} >Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Login