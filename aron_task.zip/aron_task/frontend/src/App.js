import {BrowserRouter as Router, Routes, Route, Navigate} from "react-router-dom"
import './App.css';
import Navbar from "./components/Navbar";
import Home from "./components/Home";
import CheckUserSession from "./context/CheckUserSession";
import Login from "./components/Login";
import Logout from "./components/Logout";
import ManageUsersDashboard from "./components/ManageUsersDashboard"
import env from "./env"
import AdminRoutes from "./components/AdminRoutes";
import Signup from "./components/Signup";

function App() {
  return (
    <>
      <Router>
        <CheckUserSession>
          <div className='container-fluid pt-5 mt-4'>
            <Navbar/>
            <Routes>
              <Route path="*" element={<Home/>}></Route>
              <Route exact path="/home" element={<Home/>}></Route>
              <Route exact path="/manage-users" element={
                <AdminRoutes>
                  <ManageUsersDashboard/>
                </AdminRoutes>
              }></Route>
              <Route path="/login" element={<Login/>}></Route>
              <Route path="/signup" element={<Signup/>}></Route>
              <Route path="/logout" element={<Logout/>}></Route>
            </Routes>
          </div>
        </CheckUserSession>
      </Router>
    </>
  );
}

export default App;
