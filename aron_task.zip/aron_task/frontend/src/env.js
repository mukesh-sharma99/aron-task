const arr = {
    "SERVER_PORT" : 1900,
    "SERVER_URI" : "http://localhost:",
}
export default arr