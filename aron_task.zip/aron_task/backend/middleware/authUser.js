const jwt = require('jsonwebtoken')
const JWT_SECRET = process.env.JWT_SECRET

const authUser = (req,res,next) => {
    const authToken = req.header('authToken')
    let message = "Unauthorized!"
    let response = {}
    let status = 200
    let success = 1
    try{
        if(!authToken){
            throw message
        }
        const data = jwt.verify(authToken,JWT_SECRET)
        req.user = data.user
        next()
        return
    }catch(err){
        response['error'] = err
        message = err.message
        success = 0
        status = 400
    }
    res.status(status).json({response})
}

module.exports = authUser