const jwt = require('jsonwebtoken')
const JWT_SECRET = process.env.JWT_SECRET

const isAdmin = (req,res,next) => {
    const authToken = req.header('authToken')
    let message = "Unauthorized!"
    let response = {}
    let status = 200
    let success = 1
    try{
        if(req.user.usertype == "admin"){
           next()
           return
        }else{
            throw new Error(message)
        }
    }catch(err){
        response['error'] = err
        message = err.message
        success = 0
        status = 400
    }
    res.status(status).json({response})
}

module.exports = isAdmin