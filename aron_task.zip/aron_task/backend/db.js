require('dotenv').config()
const mongoose = require('mongoose')
const mongoURI = "mongodb+srv://mukesh:mukesh@cluster0.jsf4yao.mongodb.net/"


const dbName = process.env.DB_NAME
// const logger = require('./logger')
// console.log(dbName)
connectToMongo = () => {
    mongoose.connect(mongoURI + dbName,()=>{
        // logger.info('connected to mongo')
    })
    const db = mongoose.connection
    db.once('open',function(){
        console.log(`connected to db pid ${process.pid}`);
    })
    db.on('error',(err)=>{
        // logger.error("error while connecting to db " + err)
        console.log("error while connecting to db " + err)
    })
}
module.exports = connectToMongo