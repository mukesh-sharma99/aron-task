const mongoose = require('mongoose')
const {Schema} = mongoose
const moment = require('moment-timezone')

const UserSchema = new Schema({
        name: {
            type: String,
            require: true
        },
        email: {
            type: String,
            unique: true,
            required: true
        },
        password: {
            type: String,
            required: true
        },
        usertype: {
            type: String,
            required: true
        },
        city: {
            type: String,
            required: true,
        },
        state: {
            type: String,
            required: true,
        },
        country: {
            type: String,
            required: true,
        },
        created_at: {
            type: String,
            required: true,
            default: moment().format('Y-MM-DD H:mm:ss')
        },
        updated_at: {
            type: String,
            required: true,
            default: moment().format('Y-MM-DD H:mm:ss')
        }
})
const User = mongoose.model('user',UserSchema)
module.exports = User