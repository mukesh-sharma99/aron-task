require('dotenv').config()
const PORT = process.env.PORT
// -----------------------------------------------------------

const express = require('express')
const app = express()
const connectToMongo = require('./db')
const expressSession = require('express-session')
const cors = require('cors')
app.use(express.json())
app.use(cors())
app.listen(process.env.PORT, (err, res) => {
    if (err) {
        console.log(err)
        return
    }
    console.log(`app is running at port ${ PORT} pid ${process.pid}`)
})
connectToMongo()
app.use('/user', require('./routes/UserRoutes'))



