require('dotenv').config()
const User = require('../models/User')
const bcrypt = require('bcryptjs')
const jwt = require('jsonwebtoken')
const JWT_SECRET = process.env.JWT_SECRET
const moment = require('moment')

const UserController = {
    getAllUsers: async (req, res) => {
        let response = {}
        response['data'] = {}
        let message = 'controller method called'
        let status = 200
        let success = 1
        try {
            let matchCondition = {}
            let data = []
            let users,cities,states,countries = {}
            if(req.body.cityFilterValue && req.body.cityFilterValue.trim().length > 0){
                matchCondition['city'] = req.body.cityFilterValue.trim()
            }
            if(req.body.stateFilterValue && req.body.stateFilterValue.trim().length > 0){
                matchCondition['state'] = req.body.stateFilterValue.trim()
            }
            if(req.body.countryFilterValue && req.body.countryFilterValue.trim().length > 0){
                matchCondition['country'] = req.body.countryFilterValue.trim()
            }
            
            data = await User.aggregate([
                {
                    $match: matchCondition
                },
                {   
                    $group: { 
                        '_id':null,
                        records: { $push: "$$ROOT" },
                        cities:{$addToSet: "$city"},
                        states:{$addToSet: "$state"},
                        countries:{$addToSet: "$country"}
                    }
                }
            ])
            users = data['0']['records']
            cities = data['0']['cities']
            states = data['0']['states']
            countries = data['0']['countries']
          
            
            response['data']['users'] = users
            response['data']['cities'] = cities
            response['data']['states'] = states
            response['data']['countries'] = countries
        } catch (err) {
            response['error'] = err
            message = err.message
            status = 400
            success = 0
        }
        response['message'] = message
        response['status'] = status
        response['success'] = success
        res.status(status).json({ response })
    },
    
    createUser: async (req, res) => {
        let response = {}
        let message = 'User Successfully Created!'
        let status = 200
        let success = 1
        let user = {}
        let currTime = moment().format('Y-MM-DD H:mm:ss')
        try {
            let newUser = {
                name: req.body.name,
                email: req.body.email,
                city: req.body.city.toLowerCase().trim(),
                state: req.body.state.toLowerCase().trim(),
                country: req.body.country.toLowerCase().trim()
            }
            if (req.body._id) {
                user = await User.findById(req.body._id)
                response['user'] = user
                if (!user) {
                    throw new Error("User not exists")
                }
                newUser['updated_at'] = currTime
                await User.findByIdAndUpdate(req.body._id, { $set: newUser })
                newUser['_id'] = user._id
                newUser['created_at'] = user.created_at
                newUser['usertype'] = user.usertype
                user = newUser
                message = "User Successfully Updated!"
            } else {
                let salt = await bcrypt.genSalt(10)
                let secPass = await bcrypt.hash(req.body.password, salt)
                if (req.body.cpassword !== req.body.password) {
                    throw new Error("Password and confirm password should be same!")
                }
                
                newUser['password'] = secPass,
                newUser['updated_at'] = currTime
                newUser['created_at'] = currTime
                newUser['usertype'] = req.body.makeadmin ? "admin" : "user"
                user = await User.create(newUser)
            }
        } catch (err) {
            response['error'] = err
            message = err.message
            if(err["key"] !== 'undefined' && err.code == 11000){
                message = "Choose another email!"
            }
            status = 400
            success = 0
        }
        response['data'] = user
        response['message'] = message
        response['status'] = status
        response['success'] = success
        res.status(status).json({ response })
    },
    login: async (req, res) => {
        let response = {}
        let status = 200
        let success = 1
        let message = "Logged in successfully"
        try {
            let email = req.body.email
            let password = req.body.password
            let use
            let user = await User.findOne({ email })
            if (!user) {
                throw new Error("Please enter correct credentials")
            } else {
                let comparePassword = await bcrypt.compare(password, user.password)
                if (!comparePassword) {
                    throw new Error("Please enter correct credentials")
                } else {
                    let data = {
                        user: {
                            id: user.id,
                            usertype: user.usertype
                        }
                    }

                    let authToken = jwt.sign(data, JWT_SECRET)
                    data = {
                        user: {
                            email: user.email,
                            name: user.name,
                            usertype: user.usertype,
                            authToken: authToken
                        }
                    }
                    response['data'] = data
                    // response['authToken'] = authToken
                }
            }
        } catch (err) {
            response['error'] = err
            message = err.message
            status = 400
            success = 0
        }
        response['message'] = message
        response['status'] = status
        response['success'] = success
        res.status(status).json({ response })
    },
    deleteUser: async (req, res) => {
        let response = {}
        let message = ""
        let success = 1
        let status = 200
        try {
            let user = await User.findByIdAndDelete(req.params.id)
            if (!user) {
                throw new Error("User not exist")
            }
            response['data'] = user
        } catch (err) {
            response['error'] = err
            message = err.message
            success = 0
            status = 400
        }
        response['message'] = message
        response['success'] = success
        res.status(status).json({ response })
    }
}
module.exports = UserController