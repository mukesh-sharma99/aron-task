const express = require('express')
const router = express.Router()
const UserController = require('../controllers/UserController')
const authUser = require('../middleware/authUser')
const isAdmin = require('../middleware/isAdmin')

router.post('/get-all-users',authUser,isAdmin,UserController.getAllUsers)
router.post('/signup',UserController.createUser)
router.post('/login',UserController.login)
router.delete('/delete-user/:id',authUser,isAdmin,UserController.deleteUser)
module.exports = router